#ifndef AP_H_
#define AP_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "ap_def.h"

void apInit(void);
void apMain(void);

#ifdef __cplusplus
}
#endif

#endif