#ifndef MODULE_CURRENT_SENSOR_H_
#define MODULE_CURRENT_SENSOR_H_

#include "../../ap_def.h"

void currentSensorProcess(void);

#endif