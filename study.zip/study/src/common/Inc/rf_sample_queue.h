#ifndef SAMPLE_QUEUE_H_
#define SAMPLE_QUEUE_H_

#include "../def.h"

// bool rfSampleQueueInit(void);
// void rfsampleQueueUpdate(void);
// void rfsampleQueuePush(void);
// void rfsampleQueueWrite(uint32_t code);
// bool rfsampleQueueGet(uint32_t *out_code);
#endif