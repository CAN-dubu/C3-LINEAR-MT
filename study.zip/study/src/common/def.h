#ifndef DEF_H_
#define DEF_H_

#include <Arduino.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#endif